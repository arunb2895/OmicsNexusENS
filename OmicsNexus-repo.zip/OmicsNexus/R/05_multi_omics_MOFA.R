# ==============================================================================
# OmicsNexus: 05_multi_omics_MOFA.R
# Multi-omics integration
# ==============================================================================

#' Integrate multi-omics datasets using MOFA+
#'
#' @param omics_list Named list of matrices (features in rows, samples in
#'   columns), one per omics layer. Sample names must be shared across layers.
#' @param n_factors Number of latent factors to learn.
#' @param max_iter Maximum training iterations.
#' @param seed Random seed for reproducible training.
#' @return A trained MOFA model object.
#' @export
run_mofa_integration <- function(omics_list, n_factors = 8, max_iter = 1000, seed = 42) {

  if (!requireNamespace("MOFA2", quietly = TRUE)) {
    stop("[OmicsNexus] MOFA2 is required. Run: BiocManager::install('MOFA2')", call. = FALSE)
  }
  if (!is.list(omics_list) || length(omics_list) < 2) {
    stop("[OmicsNexus] `omics_list` must be a list of at least two matrices.", call. = FALSE)
  }
  if (is.null(names(omics_list))) {
    names(omics_list) <- paste0("view_", seq_along(omics_list))
  }

  shared <- Reduce(intersect, lapply(omics_list, colnames))
  if (length(shared) < 3) {
    stop(sprintf(paste0("[OmicsNexus] Only %d sample(s) are shared across every layer.\n",
                        "  Sample names must match exactly between matrices."),
                 length(shared)), call. = FALSE)
  }
  omics_list <- lapply(omics_list, function(m) as.matrix(m[, shared, drop = FALSE]))
  message(sprintf("[OmicsNexus] Integrating %d layers over %d shared samples.",
                  length(omics_list), length(shared)))

  mofa_object <- MOFA2::create_mofa(omics_list)

  data_opts  <- MOFA2::get_default_data_options(mofa_object)
  model_opts <- MOFA2::get_default_model_options(mofa_object)
  train_opts <- MOFA2::get_default_training_options(mofa_object)

  model_opts$num_factors  <- n_factors
  train_opts$maxiter      <- max_iter
  train_opts$seed         <- seed
  train_opts$convergence_mode <- "fast"

  mofa_object <- MOFA2::prepare_mofa(mofa_object,
                                     data_options     = data_opts,
                                     model_options    = model_opts,
                                     training_options = train_opts)
  MOFA2::run_mofa(mofa_object)
}
