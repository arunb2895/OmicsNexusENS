# ==============================================================================
# OmicsNexus: 02_scrna_seq.R
# Single-cell RNA-seq module
#
# End-to-end Seurat workflow: QC filtering -> normalization -> feature selection
# -> scaling -> PCA -> neighbor graph -> clustering -> UMAP -> automated
# cell-type annotation (SingleR reference-based, or Seurat reference mapping).
#
# Design goals for non-programmers:
#   * every exported function validates its inputs and fails with a plain-English
#     message that says what is wrong AND how to fix it;
#   * sensible defaults so `run_scrna_pipeline(counts)` works out of the box;
#   * every intermediate result is returned, never printed, so the Shiny layer
#     and the R console layer can share the same code path.
# ==============================================================================


# ------------------------------------------------------------------------------
# Internal helpers (not exported)
# ------------------------------------------------------------------------------

#' Stop with a friendly, actionable message
#' @keywords internal
#' @noRd
.on_stop <- function(...) {
  stop(paste0("[OmicsNexus] ", ...), call. = FALSE)
}

#' Emit a non-fatal, user-facing note
#' @keywords internal
#' @noRd
.on_note <- function(...) {
  message("[OmicsNexus] ", ...)
}

#' Assert that a package is installed, otherwise explain how to install it
#'
#' @param pkg Character scalar, package name.
#' @param repo One of "CRAN" or "Bioconductor"; controls the install hint shown.
#' @param why Character scalar describing the feature that needs the package.
#' @keywords internal
#' @noRd
.require_pkg <- function(pkg, repo = c("CRAN", "Bioconductor"), why = NULL) {
  repo <- match.arg(repo)
  if (requireNamespace(pkg, quietly = TRUE)) {
    return(invisible(TRUE))
  }
  hint <- if (repo == "CRAN") {
    sprintf('install.packages("%s")', pkg)
  } else {
    sprintf(
      'if (!requireNamespace("BiocManager")) install.packages("BiocManager"); BiocManager::install("%s")',
      pkg
    )
  }
  .on_stop(
    sprintf(
      "The package '%s' is required%s but is not installed.\n  Run this once in the R console:\n    %s",
      pkg,
      if (is.null(why)) "" else paste0(" for ", why),
      hint
    )
  )
}

#' Validate a count matrix supplied by a user
#'
#' Accepts a base matrix, a data.frame, or any sparse Matrix. Returns a
#' dgCMatrix with genes as rows and cells as columns.
#'
#' @keywords internal
#' @noRd
.validate_counts <- function(counts, arg_name = "counts") {
  if (missing(counts) || is.null(counts)) {
    .on_stop(sprintf("`%s` is missing. Supply a gene-by-cell count matrix.", arg_name))
  }

  # data.frame is the most common shape coming out of read.csv()
  if (is.data.frame(counts)) {
    non_numeric <- names(counts)[!vapply(counts, is.numeric, logical(1))]
    if (length(non_numeric) > 0) {
      .on_stop(sprintf(
        paste0(
          "`%s` contains non-numeric column(s): %s.\n",
          "  Gene names must be row names, not a column. When reading a CSV use:\n",
          "    read.csv('yourfile.csv', row.names = 1, check.names = FALSE)"
        ),
        arg_name, paste(utils::head(non_numeric, 5), collapse = ", ")
      ))
    }
    counts <- as.matrix(counts)
  }

  if (!(is.matrix(counts) || methods::is(counts, "Matrix"))) {
    .on_stop(sprintf(
      "`%s` must be a matrix, a data.frame, or a sparse Matrix; got an object of class '%s'.",
      arg_name, paste(class(counts), collapse = "/")
    ))
  }
  if (is.null(rownames(counts))) {
    .on_stop(sprintf("`%s` has no row names. Rows must be named with gene symbols or IDs.", arg_name))
  }
  if (is.null(colnames(counts))) {
    .on_stop(sprintf("`%s` has no column names. Columns must be named with cell barcodes.", arg_name))
  }
  if (nrow(counts) < 100) {
    .on_note(sprintf(
      "`%s` has only %d genes. Confirm the matrix is genes-by-cells and not cells-by-genes.",
      arg_name, nrow(counts)
    ))
  }
  if (anyDuplicated(rownames(counts)) > 0) {
    dup_n <- sum(duplicated(rownames(counts)))
    .on_note(sprintf("Collapsing %d duplicated gene name(s) by summing their counts.", dup_n))
    counts <- rowsum(as.matrix(counts), group = rownames(counts), reorder = FALSE)
  }
  if (anyDuplicated(colnames(counts)) > 0) {
    .on_stop(sprintf(
      "`%s` has duplicated cell barcodes (column names). Make them unique, e.g. with make.unique().",
      arg_name
    ))
  }

  if (anyNA(counts)) {
    .on_stop(sprintf(
      "`%s` contains missing values. Replace them with 0 (an undetected gene) before analysis.",
      arg_name
    ))
  }

  .require_pkg("Matrix", "CRAN", "sparse count storage")
  methods::as(methods::as(counts, "CsparseMatrix"), "dgCMatrix")
}

#' Validate a numeric scalar inside a closed range
#' @keywords internal
#' @noRd
.validate_num <- function(x, arg_name, lower = -Inf, upper = Inf, integerish = FALSE) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x)) {
    .on_stop(sprintf("`%s` must be a single finite number; got '%s'.", arg_name, paste(x, collapse = ", ")))
  }
  if (x < lower || x > upper) {
    .on_stop(sprintf("`%s` must be between %s and %s; got %s.", arg_name, lower, upper, x))
  }
  if (integerish && x != round(x)) {
    .on_stop(sprintf("`%s` must be a whole number; got %s.", arg_name, x))
  }
  x
}

#' Detect the mitochondrial gene prefix for common species / naming schemes
#'
#' @param features Character vector of gene names.
#' @return A regular expression matching mitochondrial genes, or NA if none found.
#' @keywords internal
#' @noRd
.detect_mt_pattern <- function(features) {
  candidates <- c(
    human_symbol = "^MT-",
    mouse_symbol = "^mt-",
    ensembl_like = "^MT[-\\.]",
    generic      = "^(MT|Mt|mt)[-\\._]"
  )
  for (pat in candidates) {
    if (any(grepl(pat, features))) {
      return(pat)
    }
  }
  NA_character_
}


# ------------------------------------------------------------------------------
# Step 1: build a Seurat object and compute QC metrics
# ------------------------------------------------------------------------------

#' Create a Seurat object and annotate per-cell quality-control metrics
#'
#' Computes the percentage of counts arising from mitochondrial and ribosomal
#' genes, which are the two standard indicators of dying cells and of
#' library-composition bias.
#'
#' @param counts Gene-by-cell raw count matrix (matrix, data.frame or sparse Matrix).
#' @param project Character scalar used as the Seurat project name.
#' @param metadata Optional data.frame of per-cell metadata. Its row names must
#'   match the column names of `counts`.
#' @param min_cells Keep genes detected in at least this many cells. Default 3.
#' @param min_features Keep cells with at least this many detected genes at
#'   object-creation time. Default 200.
#' @param mt_pattern Regular expression identifying mitochondrial genes. Leave
#'   as NULL to detect automatically (handles `MT-` and `mt-`).
#'
#' @return A Seurat object with `percent_mt` and `percent_ribo` in its metadata.
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- read.csv("counts.csv", row.names = 1, check.names = FALSE)
#' obj <- create_scrna_object(counts, project = "PilotStudy")
#' }
create_scrna_object <- function(counts,
                                project = "OmicsNexus",
                                metadata = NULL,
                                min_cells = 3,
                                min_features = 200,
                                mt_pattern = NULL) {

  .require_pkg("Seurat", "CRAN", "single-cell analysis")

  counts <- .validate_counts(counts)
  min_cells <- .validate_num(min_cells, "min_cells", lower = 0, integerish = TRUE)
  min_features <- .validate_num(min_features, "min_features", lower = 0, integerish = TRUE)

  if (!is.character(project) || length(project) != 1L) {
    .on_stop("`project` must be a single character string, e.g. 'PilotStudy'.")
  }

  if (!is.null(metadata)) {
    if (!is.data.frame(metadata)) {
      .on_stop("`metadata` must be a data.frame with one row per cell.")
    }
    if (is.null(rownames(metadata))) {
      .on_stop("`metadata` must have row names that match the cell barcodes in `counts`.")
    }
    missing_cells <- setdiff(colnames(counts), rownames(metadata))
    if (length(missing_cells) > 0) {
      .on_stop(sprintf(
        "%d cell(s) in `counts` are absent from `metadata` (e.g. %s). Row names must match column names exactly.",
        length(missing_cells), paste(utils::head(missing_cells, 3), collapse = ", ")
      ))
    }
    metadata <- metadata[colnames(counts), , drop = FALSE]
  }

  obj <- Seurat::CreateSeuratObject(
    counts       = counts,
    project      = project,
    meta.data    = metadata,
    min.cells    = min_cells,
    min.features = min_features
  )

  if (ncol(obj) == 0L) {
    .on_stop(sprintf(
      "No cells survived object creation with min_features = %d. Lower min_features and try again.",
      min_features
    ))
  }

  # --- Mitochondrial fraction -------------------------------------------------
  if (is.null(mt_pattern)) {
    mt_pattern <- .detect_mt_pattern(rownames(obj))
  }
  if (is.na(mt_pattern)) {
    .on_note(
      "No mitochondrial genes were detected, so `percent_mt` is set to 0. ",
      "If your matrix uses Ensembl IDs, map them to symbols first or pass `mt_pattern` explicitly."
    )
    obj[["percent_mt"]] <- 0
  } else {
    obj[["percent_mt"]] <- Seurat::PercentageFeatureSet(obj, pattern = mt_pattern)
  }

  # --- Ribosomal fraction (informative, never used for filtering by default) ---
  ribo_pattern <- "^(RP[SL]|Rp[sl])"
  obj[["percent_ribo"]] <- if (any(grepl(ribo_pattern, rownames(obj)))) {
    Seurat::PercentageFeatureSet(obj, pattern = ribo_pattern)
  } else {
    0
  }

  obj
}


# ------------------------------------------------------------------------------
# Step 2: QC filtering
# ------------------------------------------------------------------------------

#' Filter low-quality cells using standard scRNA-seq QC thresholds
#'
#' @param object A Seurat object produced by [create_scrna_object()].
#' @param min_features Minimum number of detected genes per cell. Default 200.
#' @param max_features Maximum number of detected genes per cell; a high value
#'   flags likely doublets. Use `Inf` to disable, or `"auto"` for the
#'   median + 3 * MAD rule. Default "auto".
#' @param max_percent_mt Maximum percentage of mitochondrial counts. Default 10
#'   (use 5 for most human tissues, 15 to 20 for metabolically active tissue).
#' @param min_counts Minimum total UMI count per cell. Default 500.
#'
#' @return A list with `object` (the filtered Seurat object) and `summary`
#'   (a data.frame recording how many cells each filter removed).
#' @export
filter_scrna_cells <- function(object,
                               min_features = 200,
                               max_features = "auto",
                               max_percent_mt = 10,
                               min_counts = 500) {

  .require_pkg("Seurat", "CRAN", "single-cell analysis")
  if (!methods::is(object, "Seurat")) {
    .on_stop("`object` must be a Seurat object. Create one first with create_scrna_object().")
  }

  min_features   <- .validate_num(min_features, "min_features", lower = 0, integerish = TRUE)
  max_percent_mt <- .validate_num(max_percent_mt, "max_percent_mt", lower = 0, upper = 100)
  min_counts     <- .validate_num(min_counts, "min_counts", lower = 0, integerish = TRUE)

  nfeat <- object[["nFeature_RNA", drop = TRUE]]

  # "auto" upper bound: robust outlier rule that adapts to the dataset rather
  # than imposing a hard-coded gene count that may not suit the tissue.
  if (identical(max_features, "auto")) {
    max_features <- stats::median(nfeat) + 3 * stats::mad(nfeat)
    .on_note(sprintf("Automatic doublet-side cutoff: max_features = %d genes.", round(max_features)))
  } else {
    max_features <- .validate_num(max_features, "max_features", lower = 1)
  }
  if (max_features <= min_features) {
    .on_stop(sprintf(
      "`max_features` (%s) must be greater than `min_features` (%s).", max_features, min_features
    ))
  }

  n_start <- ncol(object)
  keep_feat_lo <- nfeat >= min_features
  keep_feat_hi <- nfeat <= max_features
  keep_mt      <- object[["percent_mt", drop = TRUE]] <= max_percent_mt
  keep_counts  <- object[["nCount_RNA", drop = TRUE]] >= min_counts
  keep <- keep_feat_lo & keep_feat_hi & keep_mt & keep_counts

  qc_summary <- data.frame(
    filter        = c("low gene count", "high gene count (doublets)",
                      "high mitochondrial %", "low UMI count", "TOTAL RETAINED"),
    threshold     = c(sprintf(">= %s genes", min_features),
                      sprintf("<= %s genes", round(max_features)),
                      sprintf("<= %s%%", max_percent_mt),
                      sprintf(">= %s UMIs", min_counts),
                      ""),
    cells_removed = c(sum(!keep_feat_lo), sum(!keep_feat_hi),
                      sum(!keep_mt), sum(!keep_counts), n_start - sum(keep)),
    stringsAsFactors = FALSE
  )
  qc_summary$cells_removed[5] <- n_start - sum(keep)

  if (sum(keep) == 0L) {
    .on_stop(paste0(
      "Every cell was filtered out. The thresholds are too strict for this dataset.\n",
      "  Try max_percent_mt = 20, min_counts = 200, min_features = 100 and inspect the QC plots first."
    ))
  }
  if (sum(keep) < 50L) {
    .on_note(sprintf("Only %d cells passed QC. Clustering results will be unstable.", sum(keep)))
  }

  object <- subset(object, cells = colnames(object)[keep])
  .on_note(sprintf("QC retained %d of %d cells (%.1f%%).",
                   ncol(object), n_start, 100 * ncol(object) / n_start))

  list(object = object, summary = qc_summary)
}


# ------------------------------------------------------------------------------
# Step 3: automated cell-type annotation
# ------------------------------------------------------------------------------

#' Annotate cell types automatically with SingleR
#'
#' Uses a bulk-expression reference (via the celldex package) to label each cell
#' independently, then reports the majority label per cluster so that both a
#' per-cell and a per-cluster annotation are available.
#'
#' @param object A clustered Seurat object.
#' @param reference Either a character key naming a celldex reference
#'   ("hpca", "blueprint", "immgen", "mouse_rnaseq", "monaco", "dice") or a
#'   SummarizedExperiment holding a custom reference with logcounts.
#' @param labels Character vector of labels for a custom `reference`. Ignored
#'   when `reference` is a celldex key.
#' @param label_type Which celldex label granularity to use: "main" (broad,
#'   recommended) or "fine".
#' @param cluster_col Metadata column holding cluster identities. Default
#'   "seurat_clusters".
#'
#' @return The Seurat object with `singler_label` (per cell) and
#'   `singler_cluster_label` (majority vote per cluster) added to its metadata.
#' @export
annotate_cell_types <- function(object,
                                reference = "hpca",
                                labels = NULL,
                                label_type = c("main", "fine"),
                                cluster_col = "seurat_clusters") {

  .require_pkg("Seurat", "CRAN", "single-cell analysis")
  .require_pkg("SingleR", "Bioconductor", "automated cell-type annotation")
  .require_pkg("SummarizedExperiment", "Bioconductor", "reference handling")

  label_type <- match.arg(label_type)
  if (!methods::is(object, "Seurat")) {
    .on_stop("`object` must be a Seurat object.")
  }

  # --- Resolve the reference --------------------------------------------------
  if (is.character(reference)) {
    .require_pkg("celldex", "Bioconductor", "built-in annotation references")
    ref_fun <- switch(
      tolower(reference),
      hpca         = celldex::HumanPrimaryCellAtlasData,
      blueprint    = celldex::BlueprintEncodeData,
      immgen       = celldex::ImmGenData,
      mouse_rnaseq = celldex::MouseRNAseqData,
      monaco       = celldex::MonacoImmuneData,
      dice         = celldex::DatabaseImmuneCellExpressionData,
      .on_stop(sprintf(
        paste0("Unknown reference '%s'.\n",
               "  Human: 'hpca', 'blueprint', 'monaco', 'dice'.  Mouse: 'immgen', 'mouse_rnaseq'.\n",
               "  Or pass your own SummarizedExperiment together with `labels`."),
        reference
      ))
    )
    ref <- tryCatch(
      ref_fun(),
      error = function(e) .on_stop(
        "The reference dataset could not be downloaded. Check the internet connection, then retry.\n  Original message: ",
        conditionMessage(e)
      )
    )
    ref_labels <- if (label_type == "main") ref$label.main else ref$label.fine
  } else {
    if (!methods::is(reference, "SummarizedExperiment")) {
      .on_stop("A custom `reference` must be a SummarizedExperiment with a 'logcounts' assay.")
    }
    if (is.null(labels) || length(labels) != ncol(reference)) {
      .on_stop("When supplying a custom `reference`, `labels` must have one entry per reference sample.")
    }
    ref <- reference
    ref_labels <- labels
  }

  # --- Run SingleR on log-normalized data ------------------------------------
  # Seurat v5 uses `layer`, v4 uses `slot`; support both so the package works
  # on whichever version the user already has installed.
  test_data <- tryCatch(
    Seurat::GetAssayData(object, assay = "RNA", layer = "data"),
    error = function(e) Seurat::GetAssayData(object, assay = "RNA", slot = "data")
  )
  if (length(test_data) == 0L || max(test_data) == 0) {
    .on_stop("Normalized data not found. Run NormalizeData() (or run_scrna_pipeline()) before annotating.")
  }

  shared_genes <- intersect(rownames(test_data), rownames(ref))
  if (length(shared_genes) < 200L) {
    .on_stop(sprintf(
      paste0("Only %d genes overlap between your data and the reference.\n",
             "  This usually means the species or the gene ID type does not match ",
             "(for example Ensembl IDs versus gene symbols)."),
      length(shared_genes)
    ))
  }

  pred <- SingleR::SingleR(
    test   = test_data,
    ref    = ref,
    labels = ref_labels,
    de.method = "classic"
  )

  object$singler_label <- pred$pruned.labels
  object$singler_label[is.na(object$singler_label)] <- "Unassigned"
  object$singler_score <- apply(pred$scores, 1, max)

  # --- Majority vote per cluster ---------------------------------------------
  if (cluster_col %in% colnames(object[[]])) {
    clusters <- as.character(object[[cluster_col, drop = TRUE]])
    majority <- tapply(object$singler_label, clusters, function(x) names(sort(table(x), decreasing = TRUE))[1])
    object$singler_cluster_label <- unname(majority[clusters])
  } else {
    .on_note(sprintf("Cluster column '%s' not found, so only per-cell labels were added.", cluster_col))
  }

  object
}


# ------------------------------------------------------------------------------
# Step 4: the full pipeline
# ------------------------------------------------------------------------------

#' Run the complete single-cell RNA-seq pipeline
#'
#' One call takes a raw count matrix through QC, normalization, dimensionality
#' reduction, clustering, marker detection and automated cell-type annotation.
#'
#' @param counts Gene-by-cell raw count matrix.
#' @param metadata Optional per-cell metadata data.frame (row names = barcodes).
#' @param project Project name recorded in the Seurat object.
#' @param min_features,max_features,max_percent_mt,min_counts QC thresholds,
#'   passed to [filter_scrna_cells()].
#' @param normalization "LogNormalize" (fast, default) or "SCT" for
#'   variance-stabilizing transformation via `Seurat::SCTransform`.
#' @param n_variable_features Number of highly variable genes. Default 2000.
#' @param n_pcs Number of principal components used for the neighbor graph and
#'   UMAP. Default 30.
#' @param resolution Louvain resolution. Lower values give fewer, broader
#'   clusters. Default 0.5.
#' @param regress_vars Character vector of metadata columns to regress out
#'   during scaling, e.g. `c("percent_mt")`. Default NULL.
#' @param annotate Logical; run SingleR annotation. Default TRUE.
#' @param reference Reference key or SummarizedExperiment for annotation.
#' @param find_markers Logical; compute cluster marker genes. Default TRUE.
#' @param seed Random seed for reproducible UMAP and clustering. Default 42.
#' @param verbose Logical; print progress from the underlying Seurat calls.
#'
#' @return A list with elements:
#'   \describe{
#'     \item{object}{the processed Seurat object}
#'     \item{qc_summary}{data.frame of cells removed at each QC step}
#'     \item{markers}{data.frame of cluster markers, or NULL}
#'     \item{cluster_composition}{cluster-by-label contingency table, or NULL}
#'     \item{params}{the parameter set actually used, for reporting and reuse}
#'   }
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- read.csv("counts.csv", row.names = 1, check.names = FALSE)
#' res <- run_scrna_pipeline(counts, resolution = 0.4, reference = "hpca")
#' Seurat::DimPlot(res$object, group.by = "singler_cluster_label", label = TRUE)
#' head(res$markers)
#' }
run_scrna_pipeline <- function(counts,
                               metadata = NULL,
                               project = "OmicsNexus",
                               min_features = 200,
                               max_features = "auto",
                               max_percent_mt = 10,
                               min_counts = 500,
                               normalization = c("LogNormalize", "SCT"),
                               n_variable_features = 2000,
                               n_pcs = 30,
                               resolution = 0.5,
                               regress_vars = NULL,
                               annotate = TRUE,
                               reference = "hpca",
                               find_markers = TRUE,
                               seed = 42,
                               verbose = FALSE) {

  .require_pkg("Seurat", "CRAN", "single-cell analysis")
  normalization <- match.arg(normalization)

  n_variable_features <- .validate_num(n_variable_features, "n_variable_features",
                                       lower = 100, integerish = TRUE)
  n_pcs      <- .validate_num(n_pcs, "n_pcs", lower = 2, upper = 200, integerish = TRUE)
  resolution <- .validate_num(resolution, "resolution", lower = 0.01, upper = 5)
  seed       <- .validate_num(seed, "seed", integerish = TRUE)
  set.seed(seed)

  # -- 1. Object construction and QC metrics ----------------------------------
  .on_note("Step 1/7: building the Seurat object and computing QC metrics.")
  object <- create_scrna_object(counts, project = project, metadata = metadata,
                                min_features = min_features)

  # -- 2. QC filtering ---------------------------------------------------------
  .on_note("Step 2/7: filtering low-quality cells.")
  qc <- filter_scrna_cells(object,
                           min_features   = min_features,
                           max_features   = max_features,
                           max_percent_mt = max_percent_mt,
                           min_counts     = min_counts)
  object <- qc$object

  # A PCA needs more cells than components; shrink n_pcs rather than erroring.
  if (n_pcs >= ncol(object)) {
    n_pcs <- max(2, ncol(object) - 1)
    .on_note(sprintf("Reduced n_pcs to %d because only %d cells passed QC.", n_pcs, ncol(object)))
  }

  # -- 3. Normalization and feature selection ---------------------------------
  .on_note(sprintf("Step 3/7: normalizing with %s.", normalization))
  if (normalization == "SCT") {
    .require_pkg("glmGamPoi", "Bioconductor", "fast SCTransform fitting")
    object <- Seurat::SCTransform(object,
                                  variable.features.n = n_variable_features,
                                  vars.to.regress = regress_vars,
                                  vst.flavor = "v2",
                                  verbose = verbose)
    # SingleR needs a log-normalized RNA assay even when SCT drives clustering.
    Seurat::DefaultAssay(object) <- "SCT"
    object <- Seurat::NormalizeData(object, assay = "RNA", verbose = verbose)
  } else {
    object <- Seurat::NormalizeData(object,
                                    normalization.method = "LogNormalize",
                                    scale.factor = 1e4,
                                    verbose = verbose)
    object <- Seurat::FindVariableFeatures(object,
                                           selection.method = "vst",
                                           nfeatures = n_variable_features,
                                           verbose = verbose)
    object <- Seurat::ScaleData(object,
                                features = Seurat::VariableFeatures(object),
                                vars.to.regress = regress_vars,
                                verbose = verbose)
  }

  # -- 4. Linear dimensionality reduction -------------------------------------
  .on_note("Step 4/7: running PCA.")
  object <- Seurat::RunPCA(object,
                           features = Seurat::VariableFeatures(object),
                           npcs = n_pcs,
                           seed.use = seed,
                           verbose = verbose)

  # -- 5. Graph construction, clustering and UMAP -----------------------------
  .on_note(sprintf("Step 5/7: clustering at resolution %.2f.", resolution))
  object <- Seurat::FindNeighbors(object, dims = seq_len(n_pcs), verbose = verbose)
  object <- Seurat::FindClusters(object, resolution = resolution, random.seed = seed,
                                 verbose = verbose)
  object <- tryCatch(
    Seurat::RunUMAP(object, dims = seq_len(n_pcs), seed.use = seed, verbose = verbose),
    error = function(e) {
      .on_note("UMAP failed (usually a missing uwot/python backend); falling back to t-SNE.")
      Seurat::RunTSNE(object, dims = seq_len(n_pcs), seed.use = seed, check_duplicates = FALSE)
    }
  )

  n_clusters <- length(levels(object$seurat_clusters))
  .on_note(sprintf("Found %d clusters across %d cells.", n_clusters, ncol(object)))

  # -- 6. Cluster markers ------------------------------------------------------
  markers <- NULL
  if (isTRUE(find_markers)) {
    if (n_clusters < 2L) {
      .on_note("Only one cluster was found, so marker detection was skipped. Try a higher `resolution`.")
    } else {
      .on_note("Step 6/7: identifying cluster marker genes.")
      markers <- tryCatch({
        m <- Seurat::FindAllMarkers(object,
                                    only.pos = TRUE,
                                    min.pct = 0.25,
                                    logfc.threshold = 0.25,
                                    verbose = verbose)
        m[order(m$cluster, -m$avg_log2FC), ]
      }, error = function(e) {
        .on_note("Marker detection failed: ", conditionMessage(e))
        NULL
      })
    }
  }

  # -- 7. Automated annotation -------------------------------------------------
  cluster_composition <- NULL
  if (isTRUE(annotate)) {
    .on_note("Step 7/7: annotating cell types.")
    object <- tryCatch(
      annotate_cell_types(object, reference = reference),
      error = function(e) {
        .on_note("Annotation was skipped: ", conditionMessage(e))
        object
      }
    )
    if ("singler_label" %in% colnames(object[[]])) {
      cluster_composition <- as.data.frame.matrix(
        table(cluster = object$seurat_clusters, label = object$singler_label)
      )
    }
  }

  list(
    object              = object,
    qc_summary          = qc$summary,
    markers             = markers,
    cluster_composition = cluster_composition,
    params = list(
      project = project, normalization = normalization,
      min_features = min_features, max_features = max_features,
      max_percent_mt = max_percent_mt, min_counts = min_counts,
      n_variable_features = n_variable_features, n_pcs = n_pcs,
      resolution = resolution, regress_vars = regress_vars,
      reference = if (is.character(reference)) reference else "custom",
      seed = seed, n_cells = ncol(object), n_clusters = n_clusters
    )
  )
}


# ------------------------------------------------------------------------------
# Plotting helpers
# ------------------------------------------------------------------------------

#' Standard scRNA-seq QC panel
#'
#' @param object A Seurat object carrying `percent_mt`.
#' @param group_by Metadata column used to split the violins. Default "orig.ident".
#' @return A patchwork/ggplot object with violin and scatter QC panels.
#' @export
plot_scrna_qc <- function(object, group_by = "orig.ident") {
  .require_pkg("Seurat", "CRAN", "single-cell analysis")
  .require_pkg("patchwork", "CRAN", "multi-panel figures")

  if (!methods::is(object, "Seurat")) {
    .on_stop("`object` must be a Seurat object.")
  }
  metrics <- intersect(c("nFeature_RNA", "nCount_RNA", "percent_mt", "percent_ribo"),
                       colnames(object[[]]))

  violins <- Seurat::VlnPlot(object, features = metrics, group.by = group_by,
                             ncol = length(metrics), pt.size = 0)
  scatter <- Seurat::FeatureScatter(object, feature1 = "nCount_RNA",
                                    feature2 = "nFeature_RNA", group.by = group_by)
  patchwork::wrap_plots(violins, scatter, ncol = 1, heights = c(1, 1))
}

#' UMAP coloured by cluster and by automated cell-type label
#'
#' @param object A processed Seurat object.
#' @param label Logical; print group labels on the embedding. Default TRUE.
#' @return A patchwork/ggplot object.
#' @export
plot_scrna_embedding <- function(object, label = TRUE) {
  .require_pkg("Seurat", "CRAN", "single-cell analysis")
  .require_pkg("patchwork", "CRAN", "multi-panel figures")

  reduction <- if ("umap" %in% names(object@reductions)) "umap" else "tsne"
  p1 <- Seurat::DimPlot(object, reduction = reduction, group.by = "seurat_clusters",
                        label = label) + ggplot2::ggtitle("Clusters")

  if ("singler_cluster_label" %in% colnames(object[[]])) {
    p2 <- Seurat::DimPlot(object, reduction = reduction,
                          group.by = "singler_cluster_label", label = label) +
      ggplot2::ggtitle("Annotated cell types")
    return(patchwork::wrap_plots(p1, p2, ncol = 2))
  }
  p1
}
