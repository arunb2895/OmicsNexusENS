# ==============================================================================
# OmicsNexus: 01_bulk_rnaseq.R
# Bulk RNA-seq and proteomics differential expression
# ==============================================================================

#' Run standard differential expression analysis for bulk RNA-seq or proteomics
#'
#' @param count_matrix Matrix or data.frame of raw counts or intensities
#'   (features in rows, samples in columns).
#' @param metadata Data.frame of sample metadata; row names must match the
#'   column names of `count_matrix`.
#' @param group_col Name of the metadata column defining the comparison groups.
#' @return A data.frame of results (log2 fold change, p-value, adjusted p-value).
#' @export
run_differential_analysis <- function(count_matrix, metadata, group_col) {

  if (!requireNamespace("DESeq2", quietly = TRUE)) {
    stop("[OmicsNexus] DESeq2 is required. Run: BiocManager::install('DESeq2')", call. = FALSE)
  }
  if (!group_col %in% colnames(metadata)) {
    stop(sprintf("[OmicsNexus] Column '%s' was not found in the metadata. Available: %s",
                 group_col, paste(colnames(metadata), collapse = ", ")), call. = FALSE)
  }
  if (!identical(colnames(count_matrix), rownames(metadata))) {
    if (!setequal(colnames(count_matrix), rownames(metadata))) {
      stop("[OmicsNexus] Sample names in the matrix and the metadata do not match.", call. = FALSE)
    }
    metadata <- metadata[colnames(count_matrix), , drop = FALSE]
  }

  col_data <- as.data.frame(metadata)
  col_data[[group_col]] <- as.factor(col_data[[group_col]])

  dds <- DESeq2::DESeqDataSetFromMatrix(
    countData = round(as.matrix(count_matrix)),
    colData   = col_data,
    design    = stats::as.formula(paste("~", group_col))
  )
  dds <- DESeq2::DESeq(dds)
  as.data.frame(DESeq2::results(dds))
}
