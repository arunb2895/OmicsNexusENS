# ==============================================================================
# OmicsNexus: 06_biomarker_discovery.R
# Machine-learning biomarker discovery and validation
#
# Wraps two complementary feature-selection strategies over any numeric feature
# matrix (integrated MOFA factor scores, a single omics block, or a fused
# multi-omics matrix):
#
#   * LASSO logistic regression (glmnet)  -> sparse, linear, interpretable
#   * Random Forest (randomForest)        -> non-linear, handles interactions
#
# The union of the two is reported, the intersection is highlighted as a
# consensus panel, and every model is evaluated on a held-out test split with
# ROC/AUC and bootstrap confidence intervals (pROC).
#
# Statistical guard rails that matter for omics-sized data (p >> n):
#   * the train/test split happens BEFORE any feature filtering or scaling, so
#     no information leaks from the test set into model fitting;
#   * scaling parameters are learned on the training set and applied to the
#     test set;
#   * cross-validation inside the training set chooses lambda / mtry;
#   * the reported AUC is the held-out AUC, never the resubstitution AUC.
# ==============================================================================


# ------------------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------------------

#' @keywords internal
#' @noRd
.bd_stop <- function(...) stop(paste0("[OmicsNexus] ", ...), call. = FALSE)

#' @keywords internal
#' @noRd
.bd_note <- function(...) message("[OmicsNexus] ", ...)

#' @keywords internal
#' @noRd
.bd_require <- function(pkg, why) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    .bd_stop(sprintf(
      "The package '%s' is required for %s but is not installed.\n  Run: install.packages(\"%s\")",
      pkg, why, pkg
    ))
  }
  invisible(TRUE)
}

#' Coerce and validate the feature matrix and the outcome vector
#'
#' @return A list with `x` (samples x features numeric matrix) and `y` (factor).
#' @keywords internal
#' @noRd
.bd_validate_xy <- function(x, y, features_in_rows = FALSE) {

  if (missing(x) || is.null(x)) .bd_stop("`x` is missing. Supply a numeric feature matrix.")
  if (missing(y) || is.null(y)) .bd_stop("`y` is missing. Supply the outcome for each sample.")

  if (is.data.frame(x)) {
    bad <- names(x)[!vapply(x, is.numeric, logical(1))]
    if (length(bad) > 0) {
      .bd_stop(sprintf(
        paste0("`x` contains non-numeric column(s): %s.\n",
               "  Sample IDs belong in the row names, and the outcome belongs in `y`, not in `x`."),
        paste(utils::head(bad, 5), collapse = ", ")
      ))
    }
    x <- as.matrix(x)
  }
  if (!is.matrix(x) || !is.numeric(x)) {
    .bd_stop(sprintf("`x` must be a numeric matrix or data.frame; got class '%s'.",
                     paste(class(x), collapse = "/")))
  }

  # Omics matrices are conventionally features x samples; models want the
  # transpose. Transpose explicitly rather than guessing from the shape.
  if (isTRUE(features_in_rows)) {
    x <- t(x)
  }

  if (is.null(colnames(x))) {
    colnames(x) <- paste0("feature_", seq_len(ncol(x)))
    .bd_note("`x` had no feature names, so generic names were assigned.")
  }
  if (is.null(rownames(x))) {
    rownames(x) <- paste0("sample_", seq_len(nrow(x)))
  }

  # --- Align y with x ---------------------------------------------------------
  if (is.data.frame(y)) {
    if (ncol(y) != 1L) .bd_stop("`y` must be a vector or a one-column data.frame.")
    y_names <- rownames(y)
    y <- y[[1]]
    names(y) <- y_names
  }
  if (length(y) != nrow(x)) {
    .bd_stop(sprintf(
      paste0("`x` has %d samples but `y` has %d values.\n",
             "  If your matrix is features-by-samples, call the function with features_in_rows = TRUE."),
      nrow(x), length(y)
    ))
  }
  if (!is.null(names(y)) && !is.null(rownames(x))) {
    if (!identical(names(y), rownames(x))) {
      if (setequal(names(y), rownames(x))) {
        y <- y[rownames(x)]
        .bd_note("Reordered `y` to match the sample order of `x`.")
      } else {
        .bd_note("Sample names in `x` and `y` do not match; assuming they are already in the same order.")
      }
    }
  }

  # --- Outcome checks ---------------------------------------------------------
  if (anyNA(y)) {
    keep <- !is.na(y)
    .bd_note(sprintf("Dropping %d sample(s) with a missing outcome.", sum(!keep)))
    x <- x[keep, , drop = FALSE]
    y <- y[keep]
  }
  y <- droplevels(as.factor(y))
  if (nlevels(y) < 2L) {
    .bd_stop("`y` has only one class. Biomarker discovery needs at least two groups to compare.")
  }
  if (nlevels(y) > 2L) {
    .bd_stop(sprintf(
      paste0("`y` has %d classes (%s). This module implements two-class discovery.\n",
             "  Subset to two groups, or collapse the levels, and rerun."),
      nlevels(y), paste(levels(y), collapse = ", ")
    ))
  }
  if (min(table(y)) < 5L) {
    .bd_note(sprintf(
      "The smallest class has only %d samples. Results will be unstable; treat them as exploratory.",
      min(table(y))
    ))
  }

  list(x = x, y = y)
}

#' Remove uninformative features and impute residual missing values
#'
#' Filtering statistics come only from the training rows, which is what keeps
#' the held-out estimate honest.
#'
#' @keywords internal
#' @noRd
.bd_preprocess <- function(x_train, x_test, variance_quantile = 0, impute = TRUE) {

  # --- Missing values ---------------------------------------------------------
  if (anyNA(x_train) || anyNA(x_test)) {
    if (!isTRUE(impute)) {
      .bd_stop("`x` contains missing values. Set impute = TRUE, or impute them upstream.")
    }
    feature_median <- apply(x_train, 2, stats::median, na.rm = TRUE)
    feature_median[!is.finite(feature_median)] <- 0
    fill <- function(m) {
      idx <- which(is.na(m), arr.ind = TRUE)
      if (nrow(idx) > 0) m[idx] <- feature_median[idx[, "col"]]
      m
    }
    n_missing <- sum(is.na(x_train)) + sum(is.na(x_test))
    x_train <- fill(x_train)
    x_test  <- fill(x_test)
    .bd_note(sprintf("Imputed %d missing value(s) with the training-set feature median.", n_missing))
  }

  # --- Drop constant features -------------------------------------------------
  feature_sd <- apply(x_train, 2, stats::sd)
  keep <- is.finite(feature_sd) & feature_sd > 0
  if (sum(keep) == 0L) {
    .bd_stop("Every feature is constant in the training split, so nothing can be modelled.")
  }
  if (sum(!keep) > 0) {
    .bd_note(sprintf("Removed %d constant feature(s).", sum(!keep)))
  }

  # --- Optional variance pre-filter (speeds up very wide matrices) ------------
  if (variance_quantile > 0) {
    cutoff <- stats::quantile(feature_sd[keep], probs = variance_quantile, na.rm = TRUE)
    keep <- keep & feature_sd >= cutoff
    .bd_note(sprintf("Variance pre-filter kept the top %.0f%% most variable features (%d remaining).",
                     100 * (1 - variance_quantile), sum(keep)))
  }

  x_train <- x_train[, keep, drop = FALSE]
  x_test  <- x_test[, keep, drop = FALSE]

  # --- Standardize using training-set statistics ------------------------------
  centers <- colMeans(x_train)
  scales  <- apply(x_train, 2, stats::sd)
  scales[scales == 0] <- 1

  x_train <- scale(x_train, center = centers, scale = scales)
  x_test  <- scale(x_test,  center = centers, scale = scales)

  list(x_train = x_train, x_test = x_test, centers = centers, scales = scales)
}

#' Stratified train/test split
#' @keywords internal
#' @noRd
.bd_split <- function(y, train_fraction) {
  idx <- unlist(lapply(levels(y), function(lv) {
    pool <- which(y == lv)
    if (length(pool) < 2L) {
      .bd_stop(sprintf(
        "Class '%s' has only one sample, so it cannot be split into training and test sets.",
        lv
      ))
    }
    # Always keep at least one training and one test sample per class.
    n_train <- min(max(1L, round(length(pool) * train_fraction)), length(pool) - 1L)
    sample(pool, n_train)
  }))
  sort(idx)
}


# ------------------------------------------------------------------------------
# Model 1: LASSO logistic regression
# ------------------------------------------------------------------------------

#' Select biomarkers with LASSO-penalized logistic regression
#'
#' @param x_train Scaled training matrix (samples x features).
#' @param y_train Training outcome factor; the second level is the positive class.
#' @param alpha Elastic-net mixing parameter: 1 = LASSO (default), 0 = ridge,
#'   values in between = elastic net (useful when features are highly correlated).
#' @param n_folds Number of cross-validation folds. Default 10.
#' @param lambda_rule "lambda.1se" (sparser, more conservative, default) or
#'   "lambda.min" (best cross-validated deviance).
#' @param n_repeats Repeats of the whole cross-validation, averaged to stabilize
#'   the lambda choice on small datasets. Default 1.
#'
#' @return A list with the fitted `model`, the chosen `lambda`, and a data.frame
#'   of `selected` features with their non-zero coefficients.
#' @export
fit_lasso_biomarkers <- function(x_train, y_train,
                                 alpha = 1,
                                 n_folds = 10,
                                 lambda_rule = c("lambda.1se", "lambda.min"),
                                 n_repeats = 1) {

  .bd_require("glmnet", "LASSO feature selection")
  lambda_rule <- match.arg(lambda_rule)

  # Folds cannot exceed the smallest class size, or cv.glmnet fails obscurely.
  n_folds <- min(n_folds, min(table(y_train)))
  if (n_folds < 3L) {
    .bd_note("Fewer than 3 usable folds; using leave-one-out cross-validation instead.")
    n_folds <- length(y_train)
  }

  # glmnet cannot estimate a fold-wise AUC reliably with fewer than about ten
  # samples per fold, so switch to binomial deviance for small training sets.
  measure <- if (length(y_train) / n_folds >= 10) "auc" else "deviance"
  if (measure == "deviance") {
    .bd_note("Using binomial deviance for cross-validation; the folds are too small for a stable AUC.")
  }

  lambdas <- numeric(n_repeats)
  cv_last <- NULL
  for (i in seq_len(n_repeats)) {
    cv_last <- glmnet::cv.glmnet(
      x = x_train, y = y_train,
      family = "binomial",
      alpha = alpha,
      nfolds = n_folds,
      type.measure = measure,
      standardize = FALSE  # already standardized in .bd_preprocess()
    )
    lambdas[i] <- cv_last[[lambda_rule]]
  }
  lambda <- stats::median(lambdas)

  model <- glmnet::glmnet(x = x_train, y = y_train, family = "binomial",
                          alpha = alpha, standardize = FALSE)

  coefs <- as.matrix(stats::coef(model, s = lambda))
  coefs <- coefs[rownames(coefs) != "(Intercept)", , drop = FALSE]
  nz <- which(coefs[, 1] != 0)

  selected <- data.frame(
    feature     = rownames(coefs)[nz],
    coefficient = as.numeric(coefs[nz, 1]),
    stringsAsFactors = FALSE
  )
  selected$direction <- ifelse(selected$coefficient > 0,
                               paste0("up in ", levels(y_train)[2]),
                               paste0("up in ", levels(y_train)[1]))
  selected <- selected[order(-abs(selected$coefficient)), ]
  rownames(selected) <- NULL

  if (nrow(selected) == 0L) {
    .bd_note(paste0(
      "LASSO selected no features at lambda.1se. The signal may be weak.\n",
      "  Try lambda_rule = 'lambda.min', or alpha = 0.5 for an elastic net."
    ))
  } else {
    .bd_note(sprintf("LASSO selected %d feature(s) at %s = %.4g.", nrow(selected), lambda_rule, lambda))
  }

  list(model = model, cv = cv_last, lambda = lambda, selected = selected)
}


# ------------------------------------------------------------------------------
# Model 2: Random Forest
# ------------------------------------------------------------------------------

#' Rank biomarkers with a Random Forest
#'
#' @param x_train Scaled training matrix (samples x features).
#' @param y_train Training outcome factor.
#' @param n_trees Number of trees. Default 1000.
#' @param mtry Features sampled per split. Default NULL = sqrt(p).
#' @param top_n Number of top-ranked features to return. Default 20.
#' @param balance_classes Logical; downsample to the smallest class in each tree,
#'   which prevents an imbalanced design from producing a majority-class-only
#'   model. Default TRUE.
#'
#' @return A list with the fitted `model` and a data.frame of `importance`
#'   ranked by mean decrease in Gini impurity and mean decrease in accuracy.
#' @export
fit_rf_biomarkers <- function(x_train, y_train,
                              n_trees = 1000,
                              mtry = NULL,
                              top_n = 20,
                              balance_classes = TRUE) {

  .bd_require("randomForest", "Random Forest feature ranking")

  if (is.null(mtry)) mtry <- max(1, floor(sqrt(ncol(x_train))))
  mtry <- min(mtry, ncol(x_train))

  sampsize <- if (isTRUE(balance_classes)) {
    rep(min(table(y_train)), nlevels(y_train))
  } else {
    nrow(x_train)
  }

  model <- randomForest::randomForest(
    x = x_train, y = y_train,
    ntree = n_trees,
    mtry = mtry,
    sampsize = sampsize,
    strata = if (isTRUE(balance_classes)) y_train else NULL,
    importance = TRUE
  )

  imp <- as.data.frame(randomForest::importance(model))
  imp$feature <- rownames(imp)
  acc_col  <- if ("MeanDecreaseAccuracy" %in% names(imp)) "MeanDecreaseAccuracy" else names(imp)[1]
  gini_col <- if ("MeanDecreaseGini" %in% names(imp)) "MeanDecreaseGini" else names(imp)[2]

  importance <- data.frame(
    feature       = imp$feature,
    mean_dec_acc  = imp[[acc_col]],
    mean_dec_gini = imp[[gini_col]],
    stringsAsFactors = FALSE
  )
  importance <- importance[order(-importance$mean_dec_gini), ]
  rownames(importance) <- NULL

  oob <- model$err.rate[n_trees, "OOB"]
  .bd_note(sprintf("Random Forest out-of-bag error: %.1f%% (mtry = %d, %d trees).",
                   100 * oob, mtry, n_trees))

  list(model = model, importance = utils::head(importance, top_n),
       importance_full = importance, oob_error = oob)
}


# ------------------------------------------------------------------------------
# Main entry point
# ------------------------------------------------------------------------------

#' Discover and validate multi-omics biomarkers
#'
#' Runs LASSO and Random Forest on the same stratified training split, scores
#' both on the held-out test split, and returns a consensus feature panel plus
#' publication-ready importance and ROC figures.
#'
#' @param x Numeric feature matrix. Samples in rows by default; set
#'   `features_in_rows = TRUE` for the omics convention (features x samples).
#'   MOFA factor score matrices from `R/05_multi_omics_MOFA.R` can be passed
#'   directly.
#' @param y Outcome for each sample: a two-level factor, or anything coercible
#'   to one (character, 0/1 numeric).
#' @param features_in_rows Logical; TRUE if `x` is features x samples.
#' @param positive_class The class treated as the event when computing ROC/AUC.
#'   Defaults to the second factor level.
#' @param train_fraction Proportion of samples used for training. Default 0.7.
#'   Set to 1 to train on everything and report cross-validated performance only.
#' @param variance_quantile Drop features below this quantile of training-set
#'   standard deviation, e.g. 0.5 keeps the top half. Default 0 (keep all).
#' @param impute Logical; median-impute missing values. Default TRUE.
#' @param alpha Elastic-net mixing parameter for glmnet. Default 1 (LASSO).
#' @param lambda_rule "lambda.1se" or "lambda.min".
#' @param n_folds Cross-validation folds inside the training split. Default 10.
#' @param n_trees Number of Random Forest trees. Default 1000.
#' @param top_n Number of features shown in the importance plot. Default 20.
#' @param seed Random seed for a reproducible split and reproducible models.
#'
#' @return An object of class `omicsnexus_biomarkers`: a list with
#'   \describe{
#'     \item{lasso, rf}{the fitted model objects and their selections}
#'     \item{consensus}{features selected by LASSO and top-ranked by RF}
#'     \item{performance}{held-out AUC, accuracy, sensitivity and specificity}
#'     \item{roc}{pROC roc objects for each model}
#'     \item{plots}{ggplot objects: `importance`, `roc`, `lasso_path`}
#'     \item{split}{the training and test sample names, for reproducibility}
#'   }
#' @export
#'
#' @examples
#' \dontrun{
#' # Factor scores from the MOFA module, or any omics matrix
#' res <- run_biomarker_discovery(factor_scores, y = metadata$disease_status)
#' res$performance
#' res$plots$roc
#' res$consensus
#' }
run_biomarker_discovery <- function(x, y,
                                    features_in_rows = FALSE,
                                    positive_class = NULL,
                                    train_fraction = 0.7,
                                    variance_quantile = 0,
                                    impute = TRUE,
                                    alpha = 1,
                                    lambda_rule = c("lambda.1se", "lambda.min"),
                                    n_folds = 10,
                                    n_trees = 1000,
                                    top_n = 20,
                                    seed = 42) {

  .bd_require("glmnet", "LASSO feature selection")
  .bd_require("randomForest", "Random Forest feature ranking")
  .bd_require("pROC", "ROC/AUC validation")
  .bd_require("ggplot2", "plotting")

  lambda_rule <- match.arg(lambda_rule)
  if (!is.numeric(train_fraction) || train_fraction <= 0 || train_fraction > 1) {
    .bd_stop("`train_fraction` must be a number greater than 0 and at most 1, e.g. 0.7.")
  }
  set.seed(seed)

  dat <- .bd_validate_xy(x, y, features_in_rows = features_in_rows)
  x <- dat$x; y <- dat$y

  # The positive class must be the SECOND factor level for glmnet and pROC to
  # agree on the direction of the ROC curve.
  if (!is.null(positive_class)) {
    if (!positive_class %in% levels(y)) {
      .bd_stop(sprintf("`positive_class` '%s' is not one of the outcome levels (%s).",
                       positive_class, paste(levels(y), collapse = ", ")))
    }
    y <- stats::relevel(y, ref = setdiff(levels(y), positive_class))
  }
  pos <- levels(y)[2]
  .bd_note(sprintf("Modelling '%s' as the positive class against '%s'.", pos, levels(y)[1]))

  # -- Split -------------------------------------------------------------------
  if (train_fraction < 1) {
    train_idx <- .bd_split(y, train_fraction)
  } else {
    train_idx <- seq_along(y)
    .bd_note("train_fraction = 1: performance is reported on the training data and is optimistic.")
  }
  test_idx <- setdiff(seq_along(y), train_idx)
  if (length(test_idx) == 0L) test_idx <- train_idx

  pp <- .bd_preprocess(x[train_idx, , drop = FALSE],
                       x[test_idx, , drop = FALSE],
                       variance_quantile = variance_quantile,
                       impute = impute)
  x_train <- pp$x_train; x_test <- pp$x_test
  y_train <- y[train_idx]; y_test <- y[test_idx]

  .bd_note(sprintf("Training on %d samples, testing on %d, using %d features.",
                   nrow(x_train), nrow(x_test), ncol(x_train)))

  # -- Fit both models ---------------------------------------------------------
  lasso <- fit_lasso_biomarkers(x_train, y_train, alpha = alpha,
                                n_folds = n_folds, lambda_rule = lambda_rule)
  rf <- fit_rf_biomarkers(x_train, y_train, n_trees = n_trees, top_n = top_n)

  # -- Held-out predictions ----------------------------------------------------
  prob_lasso <- as.numeric(stats::predict(lasso$model, newx = x_test,
                                          s = lasso$lambda, type = "response"))
  prob_rf <- stats::predict(rf$model, newdata = x_test, type = "prob")[, pos]

  roc_lasso <- pROC::roc(response = y_test, predictor = prob_lasso,
                         levels = levels(y), direction = "<", quiet = TRUE)
  roc_rf <- pROC::roc(response = y_test, predictor = prob_rf,
                      levels = levels(y), direction = "<", quiet = TRUE)

  perf_row <- function(rc, prob, label) {
    ci <- tryCatch(
      suppressWarnings(as.numeric(pROC::ci.auc(rc, method = "bootstrap", boot.n = 1000))),
      error = function(e) c(NA, as.numeric(pROC::auc(rc)), NA)
    )
    best <- pROC::coords(rc, "best", best.method = "youden",
                         ret = c("threshold", "sensitivity", "specificity", "accuracy"),
                         transpose = FALSE)
    best <- best[1, , drop = FALSE]
    data.frame(
      model       = label,
      auc         = as.numeric(pROC::auc(rc)),
      auc_ci_low  = ci[1],
      auc_ci_high = ci[3],
      threshold   = best$threshold,
      sensitivity = best$sensitivity,
      specificity = best$specificity,
      accuracy    = best$accuracy,
      stringsAsFactors = FALSE
    )
  }
  performance <- rbind(perf_row(roc_lasso, prob_lasso, "LASSO"),
                       perf_row(roc_rf, prob_rf, "Random Forest"))
  rownames(performance) <- NULL

  # -- Consensus panel ---------------------------------------------------------
  lasso_features <- lasso$selected$feature
  rf_features    <- rf$importance$feature
  consensus <- intersect(lasso_features, rf_features)

  consensus_tbl <- data.frame(
    feature = union(lasso_features, rf_features),
    stringsAsFactors = FALSE
  )
  consensus_tbl$lasso_coefficient <- lasso$selected$coefficient[
    match(consensus_tbl$feature, lasso$selected$feature)]
  consensus_tbl$rf_importance <- rf$importance_full$mean_dec_gini[
    match(consensus_tbl$feature, rf$importance_full$feature)]
  consensus_tbl$selected_by <- ifelse(
    consensus_tbl$feature %in% consensus, "both (consensus)",
    ifelse(consensus_tbl$feature %in% lasso_features, "LASSO", "Random Forest")
  )
  consensus_tbl <- consensus_tbl[order(consensus_tbl$selected_by != "both (consensus)",
                                       -abs(replace(consensus_tbl$rf_importance,
                                                    is.na(consensus_tbl$rf_importance), 0))), ]
  rownames(consensus_tbl) <- NULL

  .bd_note(sprintf("%d feature(s) were selected by both methods.", length(consensus)))

  # -- Figures -----------------------------------------------------------------
  plots <- list(
    importance = plot_variable_importance(rf, top_n = top_n),
    roc        = plot_biomarker_roc(list(LASSO = roc_lasso, `Random Forest` = roc_rf)),
    lasso_path = plot_lasso_path(lasso)
  )

  structure(
    list(
      lasso       = lasso,
      rf          = rf,
      consensus   = consensus_tbl,
      performance = performance,
      roc         = list(lasso = roc_lasso, rf = roc_rf),
      predictions = data.frame(sample = rownames(x_test), truth = y_test,
                               prob_lasso = prob_lasso, prob_rf = prob_rf,
                               stringsAsFactors = FALSE),
      plots       = plots,
      split       = list(train = rownames(x)[train_idx], test = rownames(x)[test_idx]),
      params      = list(positive_class = pos, train_fraction = train_fraction,
                         alpha = alpha, lambda_rule = lambda_rule,
                         n_folds = n_folds, n_trees = n_trees, seed = seed)
    ),
    class = "omicsnexus_biomarkers"
  )
}


# ------------------------------------------------------------------------------
# Plotting
# ------------------------------------------------------------------------------

#' Variable importance plot for a fitted Random Forest
#'
#' @param rf_result The list returned by [fit_rf_biomarkers()], or a
#'   `randomForest` object.
#' @param top_n Number of features to display. Default 20.
#' @return A ggplot object.
#' @export
plot_variable_importance <- function(rf_result, top_n = 20) {
  .bd_require("ggplot2", "plotting")

  imp <- if (is.list(rf_result) && !is.null(rf_result$importance_full)) {
    rf_result$importance_full
  } else if (inherits(rf_result, "randomForest")) {
    d <- as.data.frame(randomForest::importance(rf_result))
    data.frame(feature = rownames(d), mean_dec_gini = d$MeanDecreaseGini,
               mean_dec_acc = d$MeanDecreaseAccuracy, stringsAsFactors = FALSE)
  } else {
    .bd_stop("`rf_result` must come from fit_rf_biomarkers() or be a randomForest object.")
  }

  imp <- utils::head(imp[order(-imp$mean_dec_gini), ], top_n)
  imp$feature <- factor(imp$feature, levels = rev(imp$feature))

  ggplot2::ggplot(imp, ggplot2::aes(x = mean_dec_gini, y = feature,
                                    fill = mean_dec_acc)) +
    ggplot2::geom_col(width = 0.7) +
    ggplot2::scale_fill_gradient(low = "#BFD8E8", high = "#1F4E79",
                                 name = "Mean decrease\nin accuracy") +
    ggplot2::labs(
      title = sprintf("Top %d candidate biomarkers", nrow(imp)),
      subtitle = "Random Forest variable importance",
      x = "Mean decrease in Gini impurity", y = NULL
    ) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(),
                   plot.title = ggplot2::element_text(face = "bold"))
}

#' Overlay ROC curves for one or more models
#'
#' @param roc_list A named list of `pROC::roc` objects.
#' @param title Plot title.
#' @return A ggplot object.
#' @export
plot_biomarker_roc <- function(roc_list, title = "Held-out classification performance") {
  .bd_require("ggplot2", "plotting")
  .bd_require("pROC", "ROC/AUC validation")

  if (inherits(roc_list, "roc")) roc_list <- list(Model = roc_list)
  if (is.null(names(roc_list))) names(roc_list) <- paste("Model", seq_along(roc_list))

  curves <- do.call(rbind, lapply(names(roc_list), function(nm) {
    rc <- roc_list[[nm]]
    data.frame(
      model = sprintf("%s (AUC = %.3f)", nm, as.numeric(pROC::auc(rc))),
      fpr   = 1 - rc$specificities,
      tpr   = rc$sensitivities,
      stringsAsFactors = FALSE
    )
  }))
  curves <- curves[order(curves$model, curves$fpr, curves$tpr), ]

  ggplot2::ggplot(curves, ggplot2::aes(x = fpr, y = tpr, colour = model)) +
    ggplot2::geom_abline(intercept = 0, slope = 1, linetype = "dashed", colour = "grey60") +
    ggplot2::geom_path(linewidth = 1) +
    ggplot2::coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
    ggplot2::scale_colour_manual(values = c("#1F4E79", "#C0504D", "#4F8A3B", "#7B5CA8"), name = NULL) +
    ggplot2::labs(title = title,
                  x = "False positive rate (1 - specificity)",
                  y = "True positive rate (sensitivity)") +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(legend.position = "bottom",
                   legend.background = ggplot2::element_rect(fill = "white", colour = NA),
                   plot.title = ggplot2::element_text(face = "bold"))
}

#' Cross-validation curve for the LASSO fit
#'
#' Shows how the cross-validated AUC changes with the penalty, and marks the
#' two conventional lambda choices.
#'
#' @param lasso_result The list returned by [fit_lasso_biomarkers()].
#' @return A ggplot object.
#' @export
plot_lasso_path <- function(lasso_result) {
  .bd_require("ggplot2", "plotting")
  cv <- lasso_result$cv
  if (is.null(cv)) .bd_stop("No cross-validation object was stored; refit with fit_lasso_biomarkers().")

  df <- data.frame(log_lambda = log(cv$lambda), auc = cv$cvm,
                   lo = cv$cvlo, hi = cv$cvup, nzero = cv$nzero)

  ggplot2::ggplot(df, ggplot2::aes(x = log_lambda, y = auc)) +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = lo, ymax = hi),
                         fill = "#BFD8E8", alpha = 0.6) +
    ggplot2::geom_line(colour = "#1F4E79", linewidth = 1) +
    ggplot2::geom_vline(xintercept = log(cv$lambda.min), linetype = "dotted") +
    ggplot2::geom_vline(xintercept = log(cv$lambda.1se), linetype = "dashed") +
    ggplot2::labs(title = "LASSO penalty selection",
                  subtitle = "Dotted = lambda.min, dashed = lambda.1se",
                  x = expression(log(lambda)),
                  y = paste("Cross-validated", if (!is.null(cv$name)) cv$name else "error")) +
    ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(plot.title = ggplot2::element_text(face = "bold"))
}


# ------------------------------------------------------------------------------
# S3 methods
# ------------------------------------------------------------------------------

#' @export
print.omicsnexus_biomarkers <- function(x, ...) {
  cat("OmicsNexus biomarker discovery\n")
  cat(sprintf("  Positive class : %s\n", x$params$positive_class))
  cat(sprintf("  Training / test: %d / %d samples\n", length(x$split$train), length(x$split$test)))
  cat(sprintf("  LASSO selected : %d feature(s)\n", nrow(x$lasso$selected)))
  cat(sprintf("  Consensus panel: %d feature(s)\n",
              sum(x$consensus$selected_by == "both (consensus)")))
  cat("\nHeld-out performance:\n")
  print(format(x$performance, digits = 3), row.names = FALSE)
  invisible(x)
}


# ------------------------------------------------------------------------------
# Non-standard evaluation bookkeeping
#
# ggplot2 aesthetics reference data-frame columns by bare name, which R CMD check
# reports as undefined global variables. Declaring them here keeps the package
# check clean without pulling in an rlang dependency.
# ------------------------------------------------------------------------------
utils::globalVariables(c(
  "mean_dec_gini", "mean_dec_acc", "feature",
  "fpr", "tpr", "model",
  "log_lambda", "auc", "lo", "hi", "nzero"
))
