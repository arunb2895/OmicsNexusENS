# ==============================================================================
# OmicsNexus: inst/app/ui.R
# No-code Shiny front end
#
# Built with bslib (Bootstrap 5) so the layout is responsive and themable
# without hand-written CSS. Every analysis tab follows the same shape:
#
#     sidebar  = data upload + parameters + a single "Run" button
#     main     = value boxes -> interactive plotly figures -> DT tables
#
# Naming convention, so server.R stays predictable:
#     upload_<modality>        file input
#     meta_<modality>          matching metadata file input
#     <modality>_<param>       a parameter control
#     run_<modality>           the action button that triggers the analysis
#     plot_<modality>_<what>   a plotly output
#     tbl_<modality>_<what>    a DT output
#     dl_<what>                a download handler
#
# Required packages: shiny, bslib, bsicons, plotly, DT, shinyWidgets (optional).
# ==============================================================================

library(shiny)
library(bslib)
library(plotly)
library(DT)


# ------------------------------------------------------------------------------
# Small UI helpers
# ------------------------------------------------------------------------------

#' A file input plus its metadata companion, wrapped in a labelled card
#'
#' @param id_prefix Prefix used for the two input IDs, e.g. "bulk".
#' @param title Card heading shown to the user.
#' @param blurb One sentence explaining what file to upload.
#' @param accept File extensions the browser should offer.
omics_upload_card <- function(id_prefix, title, blurb,
                              accept = c(".csv", ".tsv", ".txt", ".rds")) {
  card(
    card_header(title),
    card_body(
      p(class = "text-muted small mb-2", blurb),
      fileInput(
        inputId = paste0("upload_", id_prefix),
        label = "Expression / abundance matrix (features in rows, samples in columns)",
        accept = accept, width = "100%",
        placeholder = "No file selected"
      ),
      fileInput(
        inputId = paste0("meta_", id_prefix),
        label = "Sample metadata (samples in rows, first column = sample ID)",
        accept = accept, width = "100%",
        placeholder = "Optional for exploration, required for group comparisons"
      ),
      div(
        class = "d-flex gap-2 align-items-center",
        actionLink(paste0("demo_", id_prefix), "Load example data",
                   class = "small"),
        span(class = "text-muted small", "|"),
        actionLink(paste0("help_", id_prefix), "What should this file look like?",
                   class = "small")
      ),
      uiOutput(paste0("status_", id_prefix))
    )
  )
}

#' A slider with a plain-English caption underneath
labelled_slider <- function(id, label, min, max, value, step = NULL, help = NULL) {
  tagList(
    sliderInput(id, label, min = min, max = max, value = value, step = step, width = "100%"),
    if (!is.null(help)) div(class = "text-muted small mb-3", help)
  )
}

#' Consistent "run" button
run_button <- function(id, label = "Run analysis") {
  actionButton(id, label, class = "btn-primary w-100 mt-2", icon = icon("play"))
}


# ------------------------------------------------------------------------------
# Theme
# ------------------------------------------------------------------------------

omics_theme <- bs_theme(
  version = 5,
  preset = "shiny",
  primary = "#1F4E79",
  secondary = "#4F8A3B",
  # local = FALSE links the font from the Google CDN instead of downloading the
  # files at startup, which keeps the app from failing on machines behind a
  # proxy or without write access to the font cache.
  base_font = font_google("Inter", local = FALSE),
  heading_font = font_google("Inter", local = FALSE),
  code_font = font_google("JetBrains Mono", local = FALSE)
)


# ------------------------------------------------------------------------------
# The page
# ------------------------------------------------------------------------------

ui <- page_navbar(

  title = span(
    span("OmicsNexus", class = "fw-bold"),
    span(class = "badge bg-secondary ms-2 align-middle", "beta")
  ),
  id = "main_nav",
  theme = omics_theme,
  window_title = "OmicsNexus | Multi-omics integration and biomarker discovery",
  fillable = FALSE,
  header = tags$head(
    tags$link(rel = "stylesheet", type = "text/css", href = "custom.css"),
    tags$link(rel = "icon", href = "logo.png")
  ),

  # ---------------------------------------------------------------------------
  # 1. Start here
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Start here",
    icon = icon("house"),
    layout_columns(
      col_widths = c(8, 4),
      card(
        card_header("Welcome"),
        card_body(
          h4("Multi-omics analysis without writing code"),
          p(
            "OmicsNexus takes raw count or intensity matrices through quality control, ",
            "normalization, differential testing, cross-platform integration and machine-learning ",
            "biomarker discovery. Every figure is interactive and every result table downloads as CSV."
          ),
          h5(class = "mt-4", "How to use this app"),
          tags$ol(
            tags$li(strong("Upload"), " one or more omics matrices on the Data tab, ",
                    "plus a sample metadata sheet describing your groups."),
            tags$li(strong("Analyze"), " each modality on its own tab. Defaults are set for a ",
                    "typical experiment, so you can press Run without changing anything."),
            tags$li(strong("Integrate"), " the modalities with MOFA+ or mixOmics to find shared ",
                    "axes of variation."),
            tags$li(strong("Discover"), " candidate biomarkers with LASSO and Random Forest, ",
                    "validated on a held-out test split."),
            tags$li(strong("Export"), " figures, tables and a reproducible R script from the ",
                    "Results tab.")
          ),
          div(
            class = "alert alert-info mt-3",
            bsicons::bs_icon("info-circle"),
            strong(" New to omics analysis?"),
            " Switch on Beginner Mode in the top-right of any analysis tab. ",
            "It hides advanced parameters and adds a plain-English explanation under every figure."
          )
        )
      ),
      card(
        card_header("Session status"),
        card_body(
          uiOutput("session_overview"),
          hr(),
          h6("Data loaded"),
          uiOutput("loaded_modalities"),
          hr(),
          input_switch("beginner_mode", "Beginner Mode", value = TRUE),
          div(class = "text-muted small",
              "Hides advanced options and annotates every result."),
          hr(),
          downloadButton("dl_example_bundle", "Download example dataset",
                         class = "btn-outline-secondary w-100")
        )
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 2. Data upload
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Data",
    icon = icon("upload"),
    layout_columns(
      col_widths = c(6, 6),
      omics_upload_card(
        "bulk", "Bulk RNA-seq",
        "Raw integer counts, genes in rows. Do not upload TPM or FPKM values for differential testing."
      ),
      omics_upload_card(
        "scrna", "Single-cell RNA-seq",
        "Gene-by-cell counts as CSV, or a 10x directory saved as an .rds Seurat object.",
        accept = c(".csv", ".tsv", ".rds", ".h5", ".h5ad")
      ),
      omics_upload_card(
        "spatial", "Spatial transcriptomics",
        "A Visium or Visium HD spot-by-gene matrix plus its tissue positions file.",
        accept = c(".csv", ".tsv", ".rds", ".h5")
      ),
      omics_upload_card(
        "proteomics", "Proteomics",
        "Protein-level intensities, log2 transformed or raw. Missing values are handled on the analysis tab."
      ),
      omics_upload_card(
        "metabolomics", "Metabolomics",
        "Metabolite peak intensities or concentrations, features in rows."
      ),
      card(
        card_header("Global sample metadata"),
        card_body(
          p(class = "text-muted small",
            "One sheet covering every sample across every modality. Sample IDs must match the column ",
            "names in each matrix exactly."),
          fileInput("upload_global_meta", "Metadata (CSV or TSV)",
                    accept = c(".csv", ".tsv", ".txt"), width = "100%"),
          selectInput("group_col", "Column defining the comparison groups",
                      choices = c("Upload metadata first" = ""), width = "100%"),
          selectInput("batch_col", "Batch or covariate column (optional)",
                      choices = c("None" = ""), width = "100%"),
          uiOutput("metadata_check")
        )
      )
    ),
    card(
      card_header("Preview"),
      card_body(
        navset_pill(
          nav_panel("Matrix", DTOutput("tbl_preview_matrix")),
          nav_panel("Metadata", DTOutput("tbl_preview_meta")),
          nav_panel("Sample overlap", plotlyOutput("plot_sample_overlap", height = "320px"))
        )
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 3. Bulk RNA-seq / proteomics / metabolomics
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Differential",
    icon = icon("chart-column"),
    layout_sidebar(
      sidebar = sidebar(
        width = 330, title = "Parameters",
        selectInput("de_modality", "Data to analyze",
                    choices = c("Bulk RNA-seq" = "bulk",
                                "Proteomics" = "proteomics",
                                "Metabolomics" = "metabolomics")),
        selectInput("de_method", "Statistical method",
                    choices = c("DESeq2 (raw counts)" = "deseq2",
                                "limma-voom (raw counts)" = "voom",
                                "limma (log intensities)" = "limma")),
        selectInput("de_reference", "Reference (control) group",
                    choices = c("Select metadata first" = "")),
        labelled_slider("de_fdr", "Adjusted p-value cutoff", 0.001, 0.25, 0.05, 0.005,
                        "Benjamini-Hochberg FDR. 0.05 is standard; 0.1 is acceptable for discovery."),
        labelled_slider("de_lfc", "Minimum absolute log2 fold change", 0, 3, 1, 0.1,
                        "1 means a two-fold change. Raise it to focus on larger effects."),
        conditionalPanel(
          condition = "input.beginner_mode == false",
          accordion(
            open = FALSE,
            accordion_panel(
              "Advanced",
              checkboxInput("de_shrink", "Apply log fold change shrinkage (apeglm)", TRUE),
              checkboxInput("de_independent_filter", "Independent filtering", TRUE),
              numericInput("de_min_count", "Minimum count per gene across samples", 10, min = 0),
              selectInput("de_fit_type", "Dispersion fit", c("parametric", "local", "mean"))
            )
          )
        ),
        run_button("run_de", "Run differential analysis")
      ),
      layout_columns(
        fill = FALSE, col_widths = c(3, 3, 3, 3),
        value_box("Features tested", textOutput("vb_de_tested"),
                  showcase = bsicons::bs_icon("list-ol"), theme = "primary"),
        value_box("Significant", textOutput("vb_de_sig"),
                  showcase = bsicons::bs_icon("check2-circle"), theme = "secondary"),
        value_box("Up-regulated", textOutput("vb_de_up"),
                  showcase = bsicons::bs_icon("arrow-up-circle"), theme = "success"),
        value_box("Down-regulated", textOutput("vb_de_down"),
                  showcase = bsicons::bs_icon("arrow-down-circle"), theme = "danger")
      ),
      navset_card_tab(
        nav_panel("Volcano", plotlyOutput("plot_de_volcano", height = "520px"),
                  uiOutput("explain_de_volcano")),
        nav_panel("PCA", plotlyOutput("plot_de_pca", height = "520px"),
                  uiOutput("explain_de_pca")),
        nav_panel("Heatmap", plotlyOutput("plot_de_heatmap", height = "620px")),
        nav_panel("MA plot", plotlyOutput("plot_de_ma", height = "520px")),
        nav_panel("Results table",
                  DTOutput("tbl_de_results"),
                  downloadButton("dl_de_results", "Download results (CSV)",
                                 class = "btn-outline-primary mt-3"))
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 4. Single-cell RNA-seq
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Single-cell",
    icon = icon("circle-nodes"),
    layout_sidebar(
      sidebar = sidebar(
        width = 330, title = "Parameters",
        h6("Quality control"),
        labelled_slider("sc_min_features", "Minimum genes per cell", 0, 1000, 200, 25,
                        "Cells below this are empty droplets or debris."),
        labelled_slider("sc_max_mt", "Maximum mitochondrial percent", 1, 50, 10, 1,
                        "High mitochondrial content marks stressed or dying cells. Use 5 for most tissues."),
        hr(),
        h6("Clustering"),
        labelled_slider("sc_npcs", "Principal components", 5, 100, 30, 5,
                        "How many dimensions feed the clustering. 30 suits most datasets."),
        labelled_slider("sc_resolution", "Cluster resolution", 0.1, 2.0, 0.5, 0.1,
                        "Lower gives fewer, broader clusters. Higher splits them further."),
        hr(),
        h6("Cell-type annotation"),
        checkboxInput("sc_annotate", "Annotate cell types automatically", TRUE),
        selectInput("sc_reference", "Reference atlas",
                    choices = c("Human Primary Cell Atlas" = "hpca",
                                "Blueprint / ENCODE (human)" = "blueprint",
                                "Monaco immune (human)" = "monaco",
                                "ImmGen (mouse)" = "immgen",
                                "Mouse RNA-seq" = "mouse_rnaseq")),
        conditionalPanel(
          condition = "input.beginner_mode == false",
          accordion(
            open = FALSE,
            accordion_panel(
              "Advanced",
              selectInput("sc_normalization", "Normalization",
                          c("LogNormalize" = "LogNormalize", "SCTransform" = "SCT")),
              numericInput("sc_nvar", "Highly variable genes", 2000, min = 500, step = 500),
              numericInput("sc_min_counts", "Minimum UMIs per cell", 500, min = 0, step = 100),
              checkboxInput("sc_regress_mt", "Regress out mitochondrial percent", FALSE),
              numericInput("sc_seed", "Random seed", 42, min = 1)
            )
          )
        ),
        run_button("run_scrna", "Run single-cell pipeline")
      ),
      layout_columns(
        fill = FALSE, col_widths = c(3, 3, 3, 3),
        value_box("Cells before QC", textOutput("vb_sc_cells_pre"),
                  showcase = bsicons::bs_icon("droplet"), theme = "primary"),
        value_box("Cells after QC", textOutput("vb_sc_cells_post"),
                  showcase = bsicons::bs_icon("funnel"), theme = "secondary"),
        value_box("Clusters", textOutput("vb_sc_clusters"),
                  showcase = bsicons::bs_icon("diagram-3"), theme = "success"),
        value_box("Cell types", textOutput("vb_sc_celltypes"),
                  showcase = bsicons::bs_icon("tags"), theme = "info")
      ),
      navset_card_tab(
        nav_panel("QC", plotlyOutput("plot_sc_qc", height = "520px"),
                  DTOutput("tbl_sc_qc_summary")),
        nav_panel("UMAP",
                  layout_columns(
                    col_widths = c(4, 8),
                    card(card_body(
                      selectInput("sc_umap_colour", "Colour cells by",
                                  c("Cluster" = "seurat_clusters",
                                    "Cell type" = "singler_cluster_label",
                                    "Genes detected" = "nFeature_RNA",
                                    "Mitochondrial percent" = "percent_mt")),
                      selectizeInput("sc_feature_gene", "Overlay a gene",
                                     choices = NULL, options = list(placeholder = "Type a gene symbol")),
                      input_switch("sc_show_labels", "Show labels", TRUE)
                    )),
                    plotlyOutput("plot_sc_umap", height = "560px")
                  )),
        nav_panel("Markers",
                  DTOutput("tbl_sc_markers"),
                  downloadButton("dl_sc_markers", "Download markers (CSV)",
                                 class = "btn-outline-primary mt-3")),
        nav_panel("Composition", plotlyOutput("plot_sc_composition", height = "520px"))
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 5. Spatial transcriptomics
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Spatial",
    icon = icon("map"),
    layout_sidebar(
      sidebar = sidebar(
        width = 330, title = "Parameters",
        labelled_slider("sp_min_counts", "Minimum counts per spot", 0, 2000, 200, 50,
                        "Spots below this sit outside the tissue or under a fold."),
        labelled_slider("sp_resolution", "Cluster resolution", 0.1, 2.0, 0.8, 0.1,
                        "Controls how finely the tissue is partitioned into domains."),
        selectInput("sp_deconv", "Spot deconvolution",
                    choices = c("None" = "none",
                                "RCTD (reference-based)" = "rctd",
                                "Seurat anchor transfer" = "anchor",
                                "SPOTlight (NMF)" = "spotlight")),
        conditionalPanel(
          condition = "input.sp_deconv != 'none'",
          helpText("Deconvolution needs an annotated single-cell reference. ",
                   "Run the Single-cell tab first, or upload an annotated Seurat .rds below."),
          fileInput("upload_sp_reference", "Reference Seurat object (.rds)", accept = ".rds")
        ),
        conditionalPanel(
          condition = "input.beginner_mode == false",
          accordion(
            open = FALSE,
            accordion_panel(
              "Advanced",
              checkboxInput("sp_svg", "Detect spatially variable genes (Moran's I)", TRUE),
              numericInput("sp_npcs", "Principal components", 30, min = 5, max = 100),
              selectInput("sp_norm", "Normalization", c("SCTransform" = "SCT", "LogNormalize" = "log"))
            )
          )
        ),
        run_button("run_spatial", "Run spatial pipeline")
      ),
      navset_card_tab(
        nav_panel("Tissue map",
                  layout_columns(
                    col_widths = c(4, 8),
                    card(card_body(
                      selectInput("sp_overlay", "Overlay",
                                  c("Spatial domain" = "cluster",
                                    "Gene expression" = "gene",
                                    "Cell-type proportion" = "celltype")),
                      selectizeInput("sp_gene", "Gene", choices = NULL),
                      sliderInput("sp_alpha", "Spot opacity", 0.2, 1, 0.85, 0.05)
                    )),
                    plotlyOutput("plot_spatial_map", height = "600px")
                  )),
        nav_panel("Domain composition", plotlyOutput("plot_spatial_composition", height = "520px")),
        nav_panel("Spatially variable genes",
                  DTOutput("tbl_spatial_svg"),
                  downloadButton("dl_spatial_svg", "Download (CSV)",
                                 class = "btn-outline-primary mt-3"))
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 6. Multi-omics integration
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Integration",
    icon = icon("layer-group"),
    layout_sidebar(
      sidebar = sidebar(
        width = 330, title = "Parameters",
        checkboxGroupInput(
          "int_modalities", "Layers to integrate",
          choices = c("Bulk RNA-seq" = "bulk", "Single-cell (pseudobulk)" = "scrna",
                      "Spatial (pseudobulk)" = "spatial",
                      "Proteomics" = "proteomics", "Metabolomics" = "metabolomics"),
          selected = c("bulk", "proteomics")
        ),
        selectInput("int_method", "Integration method",
                    choices = c("MOFA+ (unsupervised factors)" = "mofa",
                                "mixOmics DIABLO (supervised)" = "diablo",
                                "Sparse CCA" = "scca")),
        labelled_slider("int_nfactors", "Number of factors", 2, 20, 8, 1,
                        "Latent axes of variation shared across the layers. Start with 8."),
        labelled_slider("int_top_features", "Features per layer", 500, 10000, 2000, 500,
                        "Only the most variable features are used, which speeds up training."),
        conditionalPanel(
          condition = "input.beginner_mode == false",
          accordion(
            open = FALSE,
            accordion_panel(
              "Advanced",
              numericInput("int_maxiter", "Maximum training iterations", 1000, min = 100, step = 100),
              selectInput("int_convergence", "Convergence mode", c("fast", "medium", "slow"),
                          selected = "fast"),
              checkboxInput("int_scale_views", "Scale each layer to unit variance", TRUE),
              checkboxInput("int_center", "Center features", TRUE),
              numericInput("int_seed", "Random seed", 42, min = 1)
            )
          )
        ),
        run_button("run_integration", "Run integration")
      ),
      layout_columns(
        fill = FALSE, col_widths = c(4, 4, 4),
        value_box("Layers integrated", textOutput("vb_int_layers"),
                  showcase = bsicons::bs_icon("layers"), theme = "primary"),
        value_box("Shared samples", textOutput("vb_int_samples"),
                  showcase = bsicons::bs_icon("people"), theme = "secondary"),
        value_box("Factors retained", textOutput("vb_int_factors"),
                  showcase = bsicons::bs_icon("sliders"), theme = "success")
      ),
      navset_card_tab(
        nav_panel("Variance explained", plotlyOutput("plot_int_variance", height = "480px"),
                  uiOutput("explain_int_variance")),
        nav_panel("Factor scores",
                  layout_columns(
                    col_widths = c(4, 8),
                    card(card_body(
                      selectInput("int_factor_x", "X axis", choices = NULL),
                      selectInput("int_factor_y", "Y axis", choices = NULL),
                      selectInput("int_colour_by", "Colour by", choices = NULL)
                    )),
                    plotlyOutput("plot_int_scatter", height = "520px")
                  )),
        nav_panel("Factor weights",
                  layout_columns(
                    col_widths = c(4, 8),
                    card(card_body(
                      selectInput("int_weight_factor", "Factor", choices = NULL),
                      selectInput("int_weight_view", "Layer", choices = NULL),
                      sliderInput("int_weight_top", "Features to show", 5, 50, 15, 5)
                    )),
                    plotlyOutput("plot_int_weights", height = "520px")
                  )),
        nav_panel("Factor and group association",
                  plotlyOutput("plot_int_association", height = "480px"),
                  DTOutput("tbl_int_association"))
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 7. Biomarker discovery
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Biomarkers",
    icon = icon("bullseye"),
    layout_sidebar(
      sidebar = sidebar(
        width = 330, title = "Parameters",
        selectInput("bm_input", "Feature source",
                    choices = c("Integrated factor scores" = "factors",
                                "Fused multi-omics matrix" = "fused",
                                "A single omics layer" = "single")),
        conditionalPanel(
          condition = "input.bm_input == 'single'",
          selectInput("bm_layer", "Layer",
                      choices = c("Bulk RNA-seq" = "bulk", "Proteomics" = "proteomics",
                                  "Metabolomics" = "metabolomics"))
        ),
        selectInput("bm_outcome", "Outcome to predict", choices = c("Select metadata first" = "")),
        selectInput("bm_positive", "Positive class", choices = NULL),
        labelled_slider("bm_train_fraction", "Training set fraction", 0.5, 0.9, 0.7, 0.05,
                        "The rest is held out and never seen during training, which is what makes the AUC honest."),
        checkboxGroupInput("bm_models", "Models to run",
                           choices = c("LASSO (glmnet)" = "lasso",
                                       "Random Forest" = "rf"),
                           selected = c("lasso", "rf")),
        conditionalPanel(
          condition = "input.beginner_mode == false",
          accordion(
            open = FALSE,
            accordion_panel(
              "Advanced",
              sliderInput("bm_alpha", "Elastic-net alpha (1 = LASSO, 0 = ridge)", 0, 1, 1, 0.1),
              selectInput("bm_lambda_rule", "Penalty rule",
                          c("lambda.1se (sparser)" = "lambda.1se",
                            "lambda.min (best fit)" = "lambda.min")),
              numericInput("bm_folds", "Cross-validation folds", 10, min = 3, max = 20),
              numericInput("bm_trees", "Random Forest trees", 1000, min = 100, step = 100),
              sliderInput("bm_variance_quantile", "Drop lowest-variance features (quantile)",
                          0, 0.9, 0, 0.1),
              numericInput("bm_seed", "Random seed", 42, min = 1)
            )
          )
        ),
        run_button("run_biomarker", "Discover biomarkers")
      ),
      layout_columns(
        fill = FALSE, col_widths = c(3, 3, 3, 3),
        value_box("LASSO AUC", textOutput("vb_bm_auc_lasso"),
                  showcase = bsicons::bs_icon("graph-up"), theme = "primary"),
        value_box("Random Forest AUC", textOutput("vb_bm_auc_rf"),
                  showcase = bsicons::bs_icon("tree"), theme = "secondary"),
        value_box("Consensus features", textOutput("vb_bm_consensus"),
                  showcase = bsicons::bs_icon("intersect"), theme = "success"),
        value_box("Held-out samples", textOutput("vb_bm_test_n"),
                  showcase = bsicons::bs_icon("shield-check"), theme = "info")
      ),
      navset_card_tab(
        nav_panel("ROC curves", plotlyOutput("plot_bm_roc", height = "520px"),
                  uiOutput("explain_bm_roc")),
        nav_panel("Variable importance", plotlyOutput("plot_bm_importance", height = "560px")),
        nav_panel("Penalty selection", plotlyOutput("plot_bm_lasso_path", height = "480px")),
        nav_panel("Selected panel",
                  DTOutput("tbl_bm_consensus"),
                  downloadButton("dl_bm_panel", "Download panel (CSV)",
                                 class = "btn-outline-primary mt-3")),
        nav_panel("Per-sample predictions", DTOutput("tbl_bm_predictions"))
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 8. Results and export (the Beginner Mode download tab)
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Results",
    icon = icon("download"),
    layout_columns(
      col_widths = c(7, 5),
      card(
        card_header("Export everything"),
        card_body(
          p("Bundle every table, figure and parameter from this session into a single archive. ",
            "The archive also contains a plain R script that reproduces the whole analysis outside ",
            "the app, which is what you cite in a methods section."),
          checkboxGroupInput(
            "export_contents", "Include",
            choices = c("Result tables (CSV)" = "tables",
                        "Figures (PNG, 300 dpi)" = "png",
                        "Figures (vector PDF)" = "pdf",
                        "Reproducible R script" = "script",
                        "HTML analysis report" = "report",
                        "Processed objects (.rds)" = "rds",
                        "Session info and package versions" = "session"),
            selected = c("tables", "png", "script", "report", "session")
          ),
          layout_columns(
            col_widths = c(6, 6),
            selectInput("export_figure_format", "Figure aspect",
                        c("Single column (85 mm)" = "single",
                          "Double column (170 mm)" = "double",
                          "Slide (16:9)" = "slide")),
            numericInput("export_dpi", "Resolution (dpi)", 300, min = 72, max = 600, step = 50)
          ),
          downloadButton("dl_full_bundle", "Download results archive (.zip)",
                         class = "btn-primary btn-lg w-100 mt-2"),
          hr(),
          h6("Individual downloads"),
          div(
            class = "d-flex flex-wrap gap-2",
            downloadButton("dl_de_results_2", "Differential results", class = "btn-outline-secondary btn-sm"),
            downloadButton("dl_sc_object", "Seurat object", class = "btn-outline-secondary btn-sm"),
            downloadButton("dl_mofa_model", "MOFA model", class = "btn-outline-secondary btn-sm"),
            downloadButton("dl_bm_panel_2", "Biomarker panel", class = "btn-outline-secondary btn-sm"),
            downloadButton("dl_script", "R script", class = "btn-outline-secondary btn-sm")
          )
        )
      ),
      card(
        card_header("Analysis log"),
        card_body(
          p(class = "text-muted small",
            "Every step you ran, with the exact parameters used. Copy this into your lab notebook."),
          verbatimTextOutput("analysis_log"),
          hr(),
          h6("Methods paragraph"),
          p(class = "text-muted small", "Auto-generated text you can adapt for a manuscript."),
          verbatimTextOutput("methods_text"),
          actionButton("copy_methods", "Copy methods text",
                       class = "btn-outline-secondary btn-sm mt-2", icon = icon("copy"))
        )
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # 9. Help
  # ---------------------------------------------------------------------------
  nav_panel(
    title = "Help",
    icon = icon("circle-question"),
    layout_columns(
      col_widths = c(7, 5),
      card(
        card_header("Frequently asked questions"),
        card_body(
          accordion(
            open = FALSE,
            accordion_panel(
              "How should my count matrix be formatted?",
              p("A CSV with genes in the first column and one column per sample. The first row holds ",
                "the sample names. Values must be raw integer counts for DESeq2. No blank columns, ",
                "no merged header cells, no summary rows at the bottom."),
              tags$pre("gene,Ctrl_1,Ctrl_2,Treat_1,Treat_2\nACTB,1523,1610,1480,1502\nGAPDH,3021,2988,3105,3077")
            ),
            accordion_panel(
              "My sample names do not match between files",
              p("Sample IDs in the metadata must match the matrix column names character for character. ",
                "Spreadsheets often insert trailing spaces or convert IDs into dates. The Data tab flags ",
                "any mismatch before you run anything.")
            ),
            accordion_panel(
              "Which integration method should I choose?",
              p(strong("MOFA+"), " when you want to find the main axes of variation without telling the ",
                "model what the groups are. ", strong("DIABLO"), " when you already know the groups and ",
                "want features that discriminate them across every layer.")
            ),
            accordion_panel(
              "Why is my AUC lower here than in the paper I am reading?",
              p("This app reports performance on a held-out split that the model never saw. Reporting the ",
                "AUC on the same samples used for feature selection inflates it substantially, which is a ",
                "common source of over-optimistic biomarker claims.")
            ),
            accordion_panel(
              "The app is slow or runs out of memory",
              p("Single-cell and spatial datasets above roughly 50,000 cells need more RAM than a laptop ",
                "usually has. Reduce the number of variable features, or run the equivalent R functions ",
                "on a server using the exported script.")
            )
          )
        )
      ),
      card(
        card_header("Resources"),
        card_body(
          tags$ul(
            tags$li(tags$a(href = "https://github.com/yourusername/OmicsNexus", target = "_blank",
                           "Source code and issue tracker")),
            tags$li(tags$a(href = "https://github.com/yourusername/OmicsNexus/blob/main/vignettes/user_guide.Rmd",
                           target = "_blank", "Step-by-step user guide")),
            tags$li(tags$a(href = "https://biofam.github.io/MOFA2/", target = "_blank", "MOFA+ documentation")),
            tags$li(tags$a(href = "https://satijalab.org/seurat/", target = "_blank", "Seurat documentation"))
          ),
          hr(),
          h6("Cite OmicsNexus"),
          p(class = "small text-muted", textOutput("citation_text", inline = TRUE)),
          hr(),
          h6("Report a problem"),
          p(class = "small",
            "Include the session information from the Results tab so the error can be reproduced.")
        )
      )
    )
  ),

  # ---------------------------------------------------------------------------
  # Navbar right-hand items
  # ---------------------------------------------------------------------------
  nav_spacer(),
  # Beginner Mode appears twice on purpose: once on the landing card, once here
  # so it is reachable from every tab. server.R must keep the two in sync, and
  # `beginner_mode` is the one the conditionalPanels above read:
  #
  #   observeEvent(input$beginner_mode_nav,
  #                bslib::update_switch("beginner_mode", value = input$beginner_mode_nav))
  #   observeEvent(input$beginner_mode,
  #                bslib::update_switch("beginner_mode_nav", value = input$beginner_mode))
  nav_item(input_switch("beginner_mode_nav", "Beginner Mode", value = TRUE)),
  nav_item(
    tags$a(bsicons::bs_icon("github"), " GitHub",
           href = "https://github.com/yourusername/OmicsNexus",
           target = "_blank", class = "nav-link")
  ),
  footer = div(
    class = "text-center text-muted small py-3 border-top mt-4",
    "OmicsNexus | open source under the MIT License | ",
    "results are for research use only and are not intended for clinical decision making"
  )
)
